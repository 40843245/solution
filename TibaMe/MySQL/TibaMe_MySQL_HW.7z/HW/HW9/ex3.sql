DROP VIEW IF EXISTS DEPT20;
CREATE VIEW DEPT20 AS 
	( SELECT empno 'employee_id', ename 'employee',deptno 'department_no' FROM emp WHERE emp.deptno = 20 )
WITH CHECK OPTION;

DESCRIBE DEPT20;