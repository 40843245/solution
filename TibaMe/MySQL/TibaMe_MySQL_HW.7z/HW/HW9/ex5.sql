UPDATE DEPT20 SET department_no = 30 WHERE employee = 'SMITH';

# Error Message
# 15:52:58	UPDATE DEPT20 SET department_no = 30 WHERE employee = 'SMITH'	Error Code: 1369. CHECK OPTION failed 'company.dept20'	0.000 sec
