DROP VIEW IF EXISTS SALARY_VU;
CREATE VIEW SALARY_VU AS 
 SELECT emp.ename 'Employee',emp.deptno 'Department',emp.sal 'Salary',salgrade.grade 'Grade' FROM emp INNER JOIN salgrade ON emp.sal BETWEEN salgrade.losal AND salgrade.hisal;

SELECT * FROM SALARY_VU;