# 1.
DROP VIEW IF EXISTS EMP_VU;
CREATE VIEW EMP_VU AS SELECT empno,ename 'employee',deptno FROM emp;

DESCRIBE EMP_VU;

# 2.
SELECT employee, deptno FROM EMP_VU;

# 3.
DROP VIEW IF EXISTS DEPT20;
CREATE VIEW DEPT20 AS 
	( SELECT empno 'employee_id', ename 'employee',deptno 'department_no' FROM emp WHERE emp.deptno = 20 )
WITH CHECK OPTION;

DESCRIBE DEPT20;

# 4. 
SELECT * FROM DEPT20;

# 5.
UPDATE DEPT20 SET department_no = 30 WHERE employee = 'SMITH';

# Error Message
# 15:52:58	UPDATE DEPT20 SET department_no = 30 WHERE employee = 'SMITH'	Error Code: 1369. CHECK OPTION failed 'company.dept20'	0.000 sec

# 6.
DROP VIEW IF EXISTS SALARY_VU;
CREATE VIEW SALARY_VU AS 
 SELECT emp.ename 'Employee',emp.deptno 'Department',emp.sal 'Salary',salgrade.grade 'Grade' FROM emp INNER JOIN salgrade ON emp.sal BETWEEN salgrade.losal AND salgrade.hisal;

SELECT * FROM SALARY_VU;

# 7. 
CREATE INDEX idx_emp_ename ON EMP(ename);

SHOW INDEXES FROM EMP;