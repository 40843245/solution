# 1.
SELECT ename, sal FROM emp WHERE sal >= 2850;

# 2.
SELECT ename, deptno FROM emp WHERE empno = 7566;

# 3.
SELECT ename, sal FROM emp WHERE sal NOT BETWEEN 1500 AND 2850;

# 4.
SELECT ename,job,hiredate FROM emp WHERE hiredate BETWEEN '2011-02-20' AND '2011-05-01' ORDER BY hiredate ASC;

# 5.
SELECT ename, deptno FROM emp WHERE deptno IN (10,30) ORDER BY ename;

# 6.
SELECT ename 'Employee', sal 'Monthly Salary' FROM emp WHERE sal >= 1500 AND deptno IN(10,30);

# 7.
SELECT ename, job,hiredate FROM emp WHERE hiredate LIKE '2012%';

# 8.
SELECT ename, job FROM emp WHERE job = 'PRESIDENT';

# 9.
SELECT ename, sal, comm FROM emp WHERE sal IS NOT NULL AND comm IS NOT NULL ORDER BY sal DESC,comm DESC;

# 10.
SELECT ename, job FROM emp WHERE ename LIKE '__A%';

# 11.
## Wrong
SELECT ename, empno , deptno FROM emp WHERE ( ename LIKE '%L%L%' ) AND
(deptno = 30 OR (job = 'MANAGER' AND empno=7782) );

# 12.
SELECT ename, job,sal FROM emp WHERE job IN('CLERK','ANALYST') AND sal NOT IN(1000,3000,5000);

# 13.
SELECT ename, sal, comm FROM emp WHERE comm >= 1.1 * sal;

# 14.
SELECT empno, ename,deptno FROM emp ORDER BY hiredate ASC LIMIT 3;