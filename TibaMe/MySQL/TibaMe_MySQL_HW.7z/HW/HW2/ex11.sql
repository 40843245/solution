# 11.
SELECT ename, empno , deptno FROM emp WHERE (  ename LIKE '%L%L%'  AND
deptno = 30 ) OR (job = 'MANAGER' AND empno=7782) ;
