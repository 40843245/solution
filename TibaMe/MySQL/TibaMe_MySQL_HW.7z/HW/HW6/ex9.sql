SELECT ename,deptno,sal FROM emp WHERE ( 
	( sal IN (SELECT sal FROM emp GROUP BY sal HAVING COUNT(sal) > 1) ) AND
    (comm IS NOT NULL)
);