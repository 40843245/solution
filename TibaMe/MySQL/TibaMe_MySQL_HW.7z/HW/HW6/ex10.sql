/*
more elegant way
*/
-- way 1.
SELECT e1.ename,e1.deptno,e1.sal FROM(
	(emp e1 INNER JOIN emp e2 ON e1.sal = e2.sal AND IFNULL(e1.comm,-1) = IFNULL(e2.comm,-1) AND e1.empno != e2.empno ) 
    INNER JOIN dept ON e1.deptno = dept.deptno)
WHERE dept.loc = 'DALLAS';

/*
ugly way
*/
-- way 2.
SELECT emp.ename,emp.deptno,emp.sal FROM ( emp INNER JOIN dept ON emp.deptno = dept.deptno ) WHERE (
	( emp.deptno IN (SELECT dept.deptno FROM dept WHERE loc = 'Dallas') ) AND 
    ( sal IN (SELECT sal FROM emp GROUP BY sal HAVING COUNT(sal) > 1) ) AND
    ( IFNULL(comm,-1) IN (SELECT IFNULL(comm,-1) FROM emp GROUP BY comm HAVING COUNT(IFNULL(comm,-1) ) > 1) )
);

/*
less ugly way
*/
-- way 3.
SELECT emp.ename,emp.deptno,emp.sal FROM ( emp INNER JOIN dept ON emp.deptno = dept.deptno ) WHERE (
	( dept.loc = 'Dallas' ) AND 
    ( sal IN (SELECT sal FROM emp GROUP BY sal HAVING COUNT(sal) > 1) ) AND
    ( IFNULL(comm,-1) IN (SELECT IFNULL(comm,-1) FROM emp GROUP BY comm HAVING COUNT(IFNULL(comm,-1) ) > 1) )
);


/*
even less ugly way, but it can only be used in MySQL
*/
-- way 4.
SELECT emp.ename,emp.deptno,emp.sal FROM ( emp INNER JOIN dept ON emp.deptno = dept.deptno ) WHERE (
	( dept.loc = 'Dallas' ) AND 
    ( (emp.sal,IFNULL(emp.comm,-1)) IN (SELECT sal,IFNULL(emp.comm,-1) FROM emp 
		GROUP BY emp.sal,IFNULL(emp.comm,-1) HAVING ( ( COUNT(emp.sal) > 1 ) AND ( COUNT(IFNULL(emp.comm,-1)) > 1 ) ) ) ) 
);