# DESCRIBE my_emp;
# SELECT * FROM my_emp;
INSERT INTO my_emp (id,last_name,first_name,userid,salary) VALUES(3,'Biri','Ben','bbiri',1100);
INSERT INTO my_emp (id,last_name,first_name,userid,salary) VALUES(4,'Newman','Chad','cnewman',750);
# SELECT * FROM my_emp;