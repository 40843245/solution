# DESCRIBE my_emp;
# SELECT * FROM my_emp;
INSERT INTO my_emp VALUES(1,'Patel','Ralph','rpatel',795);
# SELECT * FROM my_emp;