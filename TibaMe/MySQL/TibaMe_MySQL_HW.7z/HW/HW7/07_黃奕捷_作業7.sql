# 1.
# DESCRIBE my_emp;
# SELECT * FROM my_emp;
INSERT INTO my_emp VALUES(1,'Patel','Ralph','rpatel',795);
# SELECT * FROM my_emp;

# 2. 
# DESCRIBE my_emp;
# SELECT * FROM my_emp;
INSERT INTO my_emp (id,last_name,first_name,userid,salary) VALUES(2,'Dancs','Betty','bdancs',860);
# SELECT * FROM my_emp;

# 3.
# DESCRIBE my_emp;
# SELECT * FROM my_emp;
INSERT INTO my_emp (id,last_name,first_name,userid,salary) VALUES(3,'Biri','Ben','bbiri',1100);
INSERT INTO my_emp (id,last_name,first_name,userid,salary) VALUES(4,'Newman','Chad','cnewman',750);
# SELECT * FROM my_emp;

# 4. 
UPDATE my_emp SET last_name = 'Drexler' WHERE id=3;

# 5.
UPDATE my_emp SET salary = 1000 WHERE salary <= 900 ;

# 6.
DELETE FROM my_emp WHERE first_name = 'Dancs' AND last_name = 'Dancs';

# 7.
START TRANSACTION;
UPDATE my_emp SET salary = salary * 1.1;
SAVEPOINT TX1;
SET SQL_SAFE_UPDATES = 0; -- disable safe operating when updating or deleting.
DELETE FROM my_emp WHERE 1; -- delete all rows from `my_emp` table.
SAVEPOINT TX2;
SELECT * FROM my_emp; -- select all rows from `my_emp` table.
SAVEPOINT TX3;

ROLLBACK TO TX3;
ROLLBACK TO TX2;
ROLLBACK TO TX1;

ROLLBACK;