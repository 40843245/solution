DESCRIBE salgrade;
SELECT emp.ename,emp.job,dept.dname,emp.sal,salgrade.grade FROM ( ( emp INNER JOIN salgrade ON emp.sal BETWEEN salgrade.losal AND salgrade.hisal ) INNER JOIN dept ON emp.deptno = dept.deptno) ;
